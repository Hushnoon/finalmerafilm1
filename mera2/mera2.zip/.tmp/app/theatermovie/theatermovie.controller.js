'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var TheatermovieComponent = function () {
    function TheatermovieComponent($http, $scope, socket) {
      _classCallCheck(this, TheatermovieComponent);

      this.$http = $http;
      this.socket = socket;
      this.movieThings = [];
      this.theaterMap = [];
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('theater');
        socket.unsyncUpdates('movie');
        //socket.unsyncUpdates('theatermovie');
      });
    }

    _createClass(TheatermovieComponent, [{
      key: '$onInit',
      value: function $onInit() {
        this.$http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q=sultantrailer&key=AIzaSyBda0gaY5pCnTsRz7rHNaDdRxQl-uIB03E').then(function (response) {

          var trailer_id = response.data.items[0].id.videoId;
          console.log('trailer_id' + trailer_id);
          var trailer = 'https://www.youtube.com/embed/' + trailer_id;
          document.getElementById('player').setAttribute("src", trailer);
        });
      }
    }]);

    return TheatermovieComponent;
  }();

  angular.module('mera2App').component('theatermovie', {
    templateUrl: 'app/theatermovie/theatermovie.html',
    controller: TheatermovieComponent
  });
})();
//# sourceMappingURL=theatermovie.controller.js.map
