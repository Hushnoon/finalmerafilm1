'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MovieshowComponent = function () {
    function MovieshowComponent($http, $scope, socket) {
      _classCallCheck(this, MovieshowComponent);

      this.$http = $http;
      this.socket = socket;
      this.movieThings = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('movie');
      });
    }

    _createClass(MovieshowComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        /*this.$http.get('/api/movies')
          .then(response => {
            this.movieThings = response.data;
            this.socket.syncUpdates('movie', this.movieThings);
          });*/
        this.$http.get('/api/theaters').then(function (response) {
          _this.theaterThings = response.data;
          _this.socket.syncUpdates('theater', _this.theaterThings);
          var flag = 0;
          for (var i = 0; i < _this.theaterThings.length; i++) {

            for (var j = 0; j < _this.theaterThings[i].slot.length; j++) {
              flag = 0;
              for (var k = 0; k < _this.movieThings.length; k++) {
                if (_this.movieThings[k]._id === _this.theaterThings[i].slot[j].movie._id) {
                  flag++;
                  break;
                }
              }
              if (flag === 0) {
                _this.movieThings.push(_this.theaterThings[i].slot[j].movie);
              }
            }
          }
        });
      }
      /*var i)ndxdMoviesByLang=[];
      moviesToFilter() {
           console.log('filter');
          this.indxdMoviesByLang= [];
          return this.movieThings;
       }A
      filterMovieByLang=function(movie){
       var movieIsNew=this.indxdMoviesByLang.indexOf(movie.Language)==-1;
       if(movieIsNew)
       {
         this.indxdMoviesByLang.push(movie.Language);
       }
      }*/

    }]);

    return MovieshowComponent;
  }();

  angular.module('mera2App').component('movieshow', {
    templateUrl: 'app/movieshow/movieshow.html',
    controller: MovieshowComponent
    // controllerAs: Movieshow
  });
})();
//# sourceMappingURL=movieshow.controller.js.map
