'use strict';

angular.module('mera2App.admin', ['mera2App.auth', 'ngRoute']);
//# sourceMappingURL=admin.module.js.map
