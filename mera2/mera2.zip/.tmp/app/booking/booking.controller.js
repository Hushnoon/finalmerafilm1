'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var BookingComponent = function () {
    function BookingComponent($http, $scope, socket, $routeParams) {
      _classCallCheck(this, BookingComponent);

      this.$http = $http;
      this.socket = socket;
      this.$routeParams = $routeParams;
      this.movieThings = [];
      this.theaterThings = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('movie');
      });
    }

    _createClass(BookingComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/theaters/' + this.$routeParams.tid).then(function (response) {
          _this.theaterThings = response.data;
          _this.socket.syncUpdates('theater', _this.theaterThings);
        });
        var letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];
        var str = '<tr><td colspan=2><center style="color:Green">ROYAL CLASS Rs.300</center></td></tr>';
        var seatno = 0;
        for (var r = 0; r < letters.length; r++) {

          str += '<center><tr class="seat"><td>' + letters[r] + '</td><td><ul class="list-inline">';
          for (var i = 1; i <= 14; i++) {
            seatno++;
            //console.log(seatno);
            if (i < 10) {
              str += '<li><a id="' + seatno + '" class="available" onclick="bookSeat(' + seatno + ')">&nbsp;' + i + '&nbsp;</a></li>';
            } else {
              str += '<li><a id="' + seatno + '" class="available" onclick="bookSeat(' + seatno + ')">' + i + '</a></li>';
            }

            if (i === 4 || i === 10) {
              str += '<li>&nbsp;&nbsp;&nbsp;</li>';
            }
          }
          str += '</ul></td></tr><center>';
          if (r === 2) {
            str += '<tr><td colspan=2 style="color:Green"><center>EXECUTIVE Rs.150</center></td></tr>';
          }
        }
        //console.log(str);
        $('#seatplan').html(str);
      }
    }, {
      key: 'pay',
      value: function pay() {}
    }]);

    return BookingComponent;
  }();

  angular.module('mera2App').component('booking', {
    templateUrl: 'app/booking/booking.html',
    controller: BookingComponent
  });
})();
//# sourceMappingURL=booking.controller.js.map
