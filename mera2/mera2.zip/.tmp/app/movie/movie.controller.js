'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MovieComponent = function () {
    function MovieComponent($http, $scope, socket) {
      _classCallCheck(this, MovieComponent);

      this.$http = $http;
      this.socket = socket;
      this.movieThings = [];
      this.showData = false;
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('thing');
      });
    }

    _createClass(MovieComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/movies').then(function (response) {
          //console.log(response.data);
          _this.movieThings = response.data;
          _this.socket.syncUpdates('movie', _this.movieThings);
        });
        //
      }
    }, {
      key: 'getData',
      value: function getData() {
        var _this2 = this;

        this.$http.get('http://www.omdbapi.com/?t=' + this.Title + '&y=' + this.Year + '&plot=short&r=json').then(function (response) {
          _this2.movieData = response.data;
          if (_this2.movieData.Response === "True") {
            _this2.showData = true;
          } else {
            _this2.showData = false;
            $.alert.open('Movie not found');
          }
          console.log(_this2.movieData);
        });
      }
    }, {
      key: 'addMovie',
      value: function addMovie() {
        if (this.movieData) {
          this.$http.post('/api/movies', JSON.stringify(this.movieData));
          this.showData = false;
        }
      }
    }, {
      key: 'deleteThing',
      value: function deleteThing(movie) {
        console.log("i callled:deleteThing");
        this.$http.delete('/api/movies/' + movie._id);
      }

      /* addThing() {
           if (this.movieName && this.movieCast && this.movieGener) {
             this.$http.post('/api/movies', {
               movieName: this.movieName,
               movieCast:this.movieCast,
               movieGener:this.movieGener
             });
            // this.newThing = '';
           }
         }*/
      /* editThing(thing)
       {
           console.log("i callled:f1");
           //$("tr").nextAll("input[type=text]").disabled=false;
           var container = document.getElementById(thing._id);
          // Find its child `input` elements
         var inputs = container.getElementsByTagName('input');
         for (var index = 0; index < inputs.length; ++index) {
             inputs[index].disabled = false;
         }
        }
       updateThing(movie) {
         console.log(movie._id);
         console.log(movie.movieName);
         console.log(movie.movieCast);
         console.log(movie.movieGener);
         console.log(this.movieGener);
         if (movie.movieName && movie.movieCast && movie.movieGener) {
           this.$http.put('/api/movies/'+movie._id, {
             movieName: movie.movieName,
             movieCast:movie.movieCast,
             movieGener:movie.movieGener
           });
          // this.newThing = ''; 
         }
         //this.$http.put('/api/movies/' + movie._id);
       }
         deleteThing(movie) {
         console.log("i callled:deleteThing")
         this.$http.delete('/api/movies/' + movie._id);
       }*/

    }]);

    return MovieComponent;
  }();

  angular.module('mera2App').component('movie', {
    templateUrl: 'app/movie/movie.html',
    controller: MovieComponent

  });
})();
//# sourceMappingURL=movie.controller.js.map
