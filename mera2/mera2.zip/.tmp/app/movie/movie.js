'use strict';

angular.module('mera2App').config(function ($routeProvider) {
  $routeProvider.when('/movie', {
    template: '<movie></movie>'
  }).when('/movieadd', {
    template: '<movieadd></movieadd>'
  });
});
//# sourceMappingURL=movie.js.map
