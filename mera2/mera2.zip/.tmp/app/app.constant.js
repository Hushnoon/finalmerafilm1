"use strict";

(function (angular, undefined) {
	angular.module("mera2App.constants", []).constant("appConfig", {
		"userRoles": ["guest", "user", "admin"]
	});
})(angular);
//# sourceMappingURL=app.constant.js.map
