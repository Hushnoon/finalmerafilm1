'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MoviebytheaterComponent = function () {
    function MoviebytheaterComponent($http, $scope, socket, $routeParams) {
      _classCallCheck(this, MoviebytheaterComponent);

      this.$http = $http;
      this.socket = socket;
      this.$routeParams = $routeParams;
      this.movieThings = [];
      this.theaterThings = [];
      this.dates = [];
      this.selectedDate = '';
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('theater');
        socket.unsyncUpdates('movie');
      });
    }

    _createClass(MoviebytheaterComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/movies/' + this.$routeParams.id).then(function (response) {
          _this.movieThings = response.data;
          _this.socket.syncUpdates('movie', _this.movieThings);
        });
        this.$http.get('/api/theaters').then(function (response) {
          _this.theaterThings = response.data;
          _this.socket.syncUpdates('theater', _this.theaterThings);
        });

        var i = 1;
        var currentDate = new Date();
        this.selectedDate = currentDate.toDateString();
        while (i <= 3) {
          // add on array
          this.dates.push({ date: currentDate.toDateString() });
          // add one day
          currentDate.setDate(currentDate.getDate() + 1);
          i++;
        }
      }
    }, {
      key: 'setDate',
      value: function setDate(dt) {
        this.selectedDate = dt;
        console.log(this.selectedDate);
      }
    }, {
      key: 'viewTrailer',
      value: function viewTrailer(movieName) {
        this.$http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q=' + movieName + 'trailer&key=AIzaSyDhoRwEX4ugfvVkDdhyQobjupOuANN2pyc').then(function (response) {

          var trailer_id = response.data.items[0].id.videoId;
          console.log('trailer_id' + trailer_id);
          var trailer = 'https://www.youtube.com/embed/' + trailer_id;
          document.getElementById('player').setAttribute("src", trailer);
          console.log('trailer');
          $("#myModal").modal('show');
        });
      }
    }]);

    return MoviebytheaterComponent;
  }();

  angular.module('mera2App').component('moviebytheater', {
    templateUrl: 'app/moviebytheater/moviebytheater.html',
    controller: MoviebytheaterComponent
  });
})();
//# sourceMappingURL=moviebytheater.controller.js.map
