'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var PaymentComponent = function PaymentComponent() {
    _classCallCheck(this, PaymentComponent);

    this.message = 'Hello';
  };

  angular.module('mera2App').component('payment', {
    templateUrl: 'app/payment/payment.html',
    controller: PaymentComponent
  });
})();
//# sourceMappingURL=payment.controller.js.map
