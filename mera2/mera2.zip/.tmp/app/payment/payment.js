'use strict';

angular.module('mera2App').config(function ($routeProvider) {
  $routeProvider.when('/payment', {
    template: '<payment></payment>'
  });
});
//# sourceMappingURL=payment.js.map
