'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var TheaterComponent = function () {
    function TheaterComponent($http, $scope, socket) {
      _classCallCheck(this, TheaterComponent);

      this.$http = $http;
      this.socket = socket;
      this.movieThings = [];
      this.theaterThings = [];
      this.update = true;
      this.stateThings = [];
      this.cityThings = [];
      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('state');
        socket.unsyncUpdates('theater');
        //socket.unsyncUpdates('movie');
      });
    }

    _createClass(TheaterComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/states').then(function (response) {
          _this.stateThings = response.data;
          _this.socket.syncUpdates('state', _this.stateThings);
        });
        this.$http.get('/api/theaters').then(function (response) {
          _this.theaterThings = response.data;
          _this.socket.syncUpdates('theater', _this.theaterThings);
        });
        this.$http.get('/api/movies').then(function (response) {
          _this.movieThings = response.data;
          _this.socket.syncUpdates('movie', _this.movieThings);
        });
      }
    }, {
      key: 'addTheater',
      value: function addTheater() {
        var _this2 = this;

        console.log('Started');
        var dates = [];

        // define the interval of your dates
        var currentDate = new Date(this.stdt);
        var endDate = new Date(this.enddt);
        console.log(currentDate);
        // create a loop between the interval
        while (currentDate <= endDate) {
          // add on array
          dates.push({ ondate: currentDate.toDateString(), seats: null });
          // add one day
          currentDate.setDate(currentDate.getDate() + 1);
        }
        console.log(dates);

        var slot1 = { time: this.slot, movie: this.selectedMovie, dateinfo: dates };
        var data = {
          name: this.name,
          location: this.location,
          city: this.selectedCity,
          state: this.selectedState.state,
          slot: slot1
        };

        this.$http.post('/api/theaters', angular.toJson(data));
        this.$http.get('/api/theaters').then(function (response) {
          _this2.theaterThings = response.data;
          _this2.socket.syncUpdates('theater', _this2.theaterThings);
        });
      }
    }, {
      key: 'addMovieSlot',
      value: function addMovieSlot() {
        var _this3 = this;

        var dates = [];
        var flag = 0;
        // define the interval of your dates
        var currentDate = new Date(this.stdt1);
        var endDate = new Date(this.enddt1);
        console.log(currentDate);
        // create a loop between the interval
        while (currentDate <= endDate) {
          // add on array
          dates.push({ ondate: currentDate.toDateString(), seats: null });
          // add one day
          currentDate.setDate(currentDate.getDate() + 1);
        }
        var slot2 = { time: this.slot1, movie: this.selectedMovie1, dateinfo: dates };
        for (var i = 0; i < this.selectedTheater1.slot.length; i++) {
          if (this.slot1 === this.selectedTheater1.slot[i].time) {
            flag++;
            break;
          }
          //console.log(this.selectedTheater1.slot[i].time);X
        }
        if (flag == 0) {
          this.selectedTheater1.slot.push(slot2);
          this.$http.put('/api/theaters/' + this.selectedTheater1._id, this.selectedTheater1);
          this.$http.get('/api/theaters').then(function (response) {
            _this3.theaterThings = response.data;
            _this3.socket.syncUpdates('theater', _this3.theaterThings);
          });
        } else {
          $.alert.open('The slot is occupied');
        }
      }
    }, {
      key: 'deleteMovie',
      value: function deleteMovie(t, s) {
        var _this4 = this;

        this.$http.delete('/api/theaters/' + t + '/slot/' + s);
        this.$http.get('/api/theaters').then(function (response) {
          _this4.theaterThings = response.data;
          _this4.socket.syncUpdates('theater', _this4.theaterThings);
        });
      }
    }, {
      key: 'setStartDate',
      value: function setStartDate() {
        this.stdt = new Date(this.selectedMovie.Released);
      }
    }, {
      key: 'setStartDate1',
      value: function setStartDate1() {
        this.stdt1 = new Date(this.selectedMovie1.Released);
      }
    }]);

    return TheaterComponent;
  }();

  angular.module('mera2App').component('theater', {
    templateUrl: 'app/theater/theater.html',
    controller: TheaterComponent
  });
})();
//# sourceMappingURL=theater.controller.js.map
