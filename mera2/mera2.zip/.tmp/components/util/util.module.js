'use strict';

angular.module('mera2App.util', []);
//# sourceMappingURL=util.module.js.map
