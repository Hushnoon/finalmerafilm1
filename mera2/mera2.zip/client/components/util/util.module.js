'use strict';

angular.module('mera2App.util', []);
