'use strict';

(function(){

class BookingComponent {
 constructor($http, $scope, socket,$routeParams) { 
      this.$http = $http;
      this.socket = socket;
      this.$routeParams = $routeParams;
      this.movieThings = [];
      this.theaterThings = [];
     
      $scope.$on('$destroy', function() {
        socket.unsyncUpdates('movie');
      });
  }
  $onInit() {
  this.$http.get('/api/theaters/'+this.$routeParams.tid)
        .then(response => {
          this.theaterThings = response.data;
          this.socket.syncUpdates('theater', this.theaterThings);
                   
      });
  var letters=['A','B','C','D','E','F','G','H','I'];
  var str='<tr><td colspan=2><center style="color:Green">ROYAL CLASS Rs.300</center></td></tr>';
  var seatno=0;
  for(var r=0;r<letters.length;r++)
  {

    str+='<center><tr class="seat"><td>'+letters[r]+'</td><td><ul class="list-inline">';
    for(var i=1;i<=14;i++)
    {
      seatno++;
      //console.log(seatno);
      if(i<10)
      {
         str+='<li><a id="'+seatno+'" class="available" onclick="bookSeat('+seatno+')">&nbsp;'+i+'&nbsp;</a></li>';
      }
      else
      {
         str+='<li><a id="'+seatno+'" class="available" onclick="bookSeat('+seatno+')">'+i+'</a></li>';
      }
     
        if(i===4||i===10)
        {
          str+='<li>&nbsp;&nbsp;&nbsp;</li>'; 
        }
    }
    str+='</ul></td></tr><center>';
    if(r===2)
    {
      str+='<tr><td colspan=2 style="color:Green"><center>EXECUTIVE Rs.150</center></td></tr>';
    }
  }
  //console.log(str);
  $('#seatplan').html(str); 
 } 
 
 pay()
 {
  
 }
      
}

angular.module('mera2App')
  .component('booking', {
    templateUrl: 'app/booking/booking.html',
    controller: BookingComponent
  });

})();
