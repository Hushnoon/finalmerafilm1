'use strict';

(function(){

class TheatermovieComponent {
  constructor($http, $scope, socket) {
      this.$http = $http;
      this.socket = socket;
      this.movieThings=[];
      this.theaterMap=[];  
      $scope.$on('$destroy', function() {
         socket.unsyncUpdates('theater');
         socket.unsyncUpdates('movie');
         //socket.unsyncUpdates('theatermovie');
       });
  } 
  $onInit() {
     this.$http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q=sultantrailer&key=AIzaSyBda0gaY5pCnTsRz7rHNaDdRxQl-uIB03E')
      .then(response => {

        var trailer_id=response.data.items[0].id.videoId;
        console.log('trailer_id'+trailer_id);
        var trailer='https://www.youtube.com/embed/'+trailer_id;
        document.getElementById('player').setAttribute("src",trailer);


});
}
}
angular.module('mera2App')
  .component('theatermovie', {
    templateUrl: 'app/theatermovie/theatermovie.html',
    controller: TheatermovieComponent
  });

})();
