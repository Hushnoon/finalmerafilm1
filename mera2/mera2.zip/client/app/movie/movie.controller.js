'use strict';

(function(){

class MovieComponent {
   constructor($http, $scope, socket) {
      this.$http = $http;
      this.socket = socket;
      this.movieThings=[];
      this.showData=false;
      $scope.$on('$destroy', function() {
        socket.unsyncUpdates('thing');
      });
    }
    $onInit() {
      this.$http.get('/api/movies') 
        .then(response => {
          //console.log(response.data);
          this.movieThings = response.data;
          this.socket.syncUpdates('movie', this.movieThings);
        });
        //
    }
    getData() 
    {
      this.$http.get('http://www.omdbapi.com/?t='+this.Title+'&y='+this.Year+'&plot=short&r=json')
     .then(response => {
      this.movieData = response.data;
      if(this.movieData.Response==="True")
      {
        this.showData=true;
      }
      else
      {
        this.showData=false;
        $.alert.open('Movie not found');
      }
      console.log(this.movieData);
      });
      
    } 

    addMovie() {
     if (this.movieData) {
       this.$http.post('/api/movies',
         JSON.stringify(this.movieData)
       );
       this.showData=false;
      
     }
   }
   deleteThing(movie) {
      console.log("i callled:deleteThing")
      this.$http.delete('/api/movies/' + movie._id);
    }
    
 /* addThing() {
      if (this.movieName && this.movieCast && this.movieGener) {
        this.$http.post('/api/movies', {
          movieName: this.movieName,
          movieCast:this.movieCast,
          movieGener:this.movieGener
        });
       // this.newThing = '';
      }
    }*/
   /* editThing(thing)
    {
        console.log("i callled:f1");
        //$("tr").nextAll("input[type=text]").disabled=false;
        var container = document.getElementById(thing._id);

      // Find its child `input` elements
      var inputs = container.getElementsByTagName('input');
      for (var index = 0; index < inputs.length; ++index) {
          inputs[index].disabled = false;
      }

    }
    updateThing(movie) {
      console.log(movie._id);
      console.log(movie.movieName);
      console.log(movie.movieCast);
      console.log(movie.movieGener);
      console.log(this.movieGener);
      if (movie.movieName && movie.movieCast && movie.movieGener) {
        this.$http.put('/api/movies/'+movie._id, {
          movieName: movie.movieName,
          movieCast:movie.movieCast,
          movieGener:movie.movieGener
        });
       // this.newThing = ''; 
      }
      //this.$http.put('/api/movies/' + movie._id);
    }

     deleteThing(movie) {
      console.log("i callled:deleteThing")
      this.$http.delete('/api/movies/' + movie._id);
    }*/
}

angular.module('mera2App')
  .component('movie', {
    templateUrl: 'app/movie/movie.html',
    controller: MovieComponent
    
  }); 

})();
 