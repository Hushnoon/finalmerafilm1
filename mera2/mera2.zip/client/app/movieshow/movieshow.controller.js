'use strict';

(function(){

class MovieshowComponent {
   constructor($http, $scope, socket) {
      this.$http = $http;
      this.socket = socket;
      this.movieThings = [];
       

      $scope.$on('$destroy', function() {
        socket.unsyncUpdates('movie');
      });
  }

  $onInit() {
      /*this.$http.get('/api/movies')
        .then(response => {
          this.movieThings = response.data;
          this.socket.syncUpdates('movie', this.movieThings);
        });*/
        this.$http.get('/api/theaters')
        .then(response => {
          this.theaterThings = response.data;
          this.socket.syncUpdates('theater',this.theaterThings);
          var flag=0;
          for (var i=0;i<this.theaterThings.length;i++)
          {   

            for(var j=0;j<this.theaterThings[i].slot.length;j++)
            {
              flag=0;
              for(var k=0;k<this.movieThings.length;k++)
              {
                if(this.movieThings[k]._id===this.theaterThings[i].slot[j].movie._id)
                {  
                  flag++;  
                  break;    
                }         
              }
              if(flag===0)
              {
                this.movieThings.push(this.theaterThings[i].slot[j].movie);
              }
            }
          }
        });
      
    }
   /*var i)ndxdMoviesByLang=[];
   moviesToFilter() {
        console.log('filter');
       this.indxdMoviesByLang= [];
       return this.movieThings;
    }A
  filterMovieByLang=function(movie){
    var movieIsNew=this.indxdMoviesByLang.indexOf(movie.Language)==-1;
    if(movieIsNew)
    {
      this.indxdMoviesByLang.push(movie.Language);
    }
  }*/
}

angular.module('mera2App')
  .component('movieshow', {
    templateUrl: 'app/movieshow/movieshow.html',
    	controller: MovieshowComponent
   // controllerAs: Movieshow
  });

})();
