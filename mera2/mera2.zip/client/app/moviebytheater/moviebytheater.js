'use strict';

angular.module('mera2App')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/moviebytheater/:id', {
        template: '<moviebytheater></moviebytheater>'
      });
  });
