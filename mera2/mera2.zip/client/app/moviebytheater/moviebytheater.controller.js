'use strict';

(function(){

class MoviebytheaterComponent {
  constructor($http, $scope, socket,$routeParams) {
      this.$http = $http;
      this.socket = socket; 
      this.$routeParams = $routeParams;
      this.movieThings=[];
      this.theaterThings=[];
      this.dates = [];
      this.selectedDate='';
      $scope.$on('$destroy', function() {
         socket.unsyncUpdates('theater');
         socket.unsyncUpdates('movie');

       });
  } 
   $onInit() {
    this.$http.get('/api/movies/'+this.$routeParams.id)
        .then(response => {
          this.movieThings = response.data;
          this.socket.syncUpdates('movie', this.movieThings);
                   
      });
    this.$http.get('/api/theaters')
        .then(response => {
          this.theaterThings = response.data;
          this.socket.syncUpdates('theater', this.theaterThings);
                   
      });

      var i=1;
      var currentDate = new Date();
      this.selectedDate=currentDate.toDateString();
      while (i<=3)
      {  
         // add on array
         this.dates.push({date:currentDate.toDateString()});
         // add one day
         currentDate.setDate(currentDate.getDate()+1);
         i++;
      }
      
    }
    setDate(dt)
    {
      this.selectedDate=dt;
      console.log(this.selectedDate);
    }
    viewTrailer(movieName)
    {
      this.$http.get('https://www.googleapis.com/youtube/v3/search?part=snippet&q='+movieName+'trailer&key=AIzaSyDhoRwEX4ugfvVkDdhyQobjupOuANN2pyc')
      .then(response => {

        var trailer_id=response.data.items[0].id.videoId;
        console.log('trailer_id'+trailer_id);
        var trailer='https://www.youtube.com/embed/'+trailer_id;
        document.getElementById('player').setAttribute("src",trailer);
        console.log('trailer');
        $("#myModal").modal('show');
      });
      
    }
}

angular.module('mera2App')
  .component('moviebytheater', {
    templateUrl: 'app/moviebytheater/moviebytheater.html',
    controller: MoviebytheaterComponent
  });

})();
