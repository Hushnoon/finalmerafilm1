'use strict';

import mongoose from 'mongoose';

var BookingSchema = new mongoose.Schema({
  name: String,
  emailid: String,
  contact:String,
  bookingdate:String,
  transactiondate:String,
  theaterName:String,
  MovieName:String,
  slot:String,
  Seats:String,
  Total:Number
});

export default mongoose.model('Booking', BookingSchema);
